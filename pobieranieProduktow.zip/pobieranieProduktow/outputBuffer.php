 <?php

    function getView($name, array $data = array())
    {
        extract($data, EXTR_SKIP);
        ob_start();

        try
        {
            include './views/'.$name.'View.php';
        }
        catch(Exception $e)
        {
            ob_end_clean();
            echo 'Wystąpił błąd!';
            return FALSE;
        }
        return ob_get_clean();
    }

?> 