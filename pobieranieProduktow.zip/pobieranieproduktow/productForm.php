<?php       

    if(isset($_POST['productLinks']))
    {
        $productLinks = explode("\n",trim($_POST['productLinks']));
        foreach ($productLinks as $productLink ) {
            $productLink =trim($productLink );
        }
        if(count($productLinks)>0 && $productLinks[0]!='')
        {
            $productLinks = array_unique($productLinks);
            $xmlString='<?xml version="1.0"?>'.PHP_EOL.'<rss xmlns:g="http://base.google.com/ns/1.0" version="2.0">';
    
            $writeToDatabase=false;
            $database = mysqli_connect('trobhoster.atthost24.pl', '6301_pobieraniep', 'pobierz123', '6301_pobieraniep');
            if($error = mysqli_connect_errno())
            {                
                $info = 'Wystąpił problem z bazą danych.';
            }
            else
            {
                $writeToDatabase=true;
            }

            foreach ($productLinks as $productLink) 
            {
                libxml_use_internal_errors(true);//zignorowanie bledow od html5
                $dom = new DOMDocument();
                $dom->loadHTMLFile($productLink);
                libxml_use_internal_errors(false);

                $product = array("id"=>"", "url"=>"", "name"=>"","price"=>"","original_price"=>"","manufacturer"=>"", "gender"=>"","description"=>"","image_url"=>"");

                $xpath = new DOMXpath($dom);
                $productData = $xpath->query('//div[@class="product__data__field"]');

                $xmlString =$xmlString.PHP_EOL.'<item>';
                if ($productData->length > 0) 
                {
                    foreach ($productData as $productDataFieldAndValue) 
                    {
                        $productDataFieldAndValue=explode("\n",str_replace(" ","|",trim($productDataFieldAndValue->nodeValue)));//zamiana spacji na podkreslenia, rozbicie po nowych liniach
                        //$productDataFieldAndValue[0]-productDataField, productDataFieldAndValue[1]-productDataFieldValue
                        
                        if(count($productDataFieldAndValue)>2)//opisy z nowymi liniami
                        {
                            $productDataField=$productDataFieldAndValue[0];
                            $productValue='';
                            for($i=1; $i<count($productDataFieldAndValue);$i++)
                            {
                                $productValue= $productValue.'~'.trim($productDataFieldAndValue[$i]) ;
                            }
                            $productDataFieldAndValue=array($productDataField,$productValue);

                        }
                        if(count($productDataFieldAndValue)==2)
                        {
                            if(trim($productDataFieldAndValue[0])=="Indeks:")
                                $product["id"]=trim($productDataFieldAndValue[1]);

                            else if(trim($productDataFieldAndValue[0])=="Producent:")
                                $product["manufacturer"]=trim($productDataFieldAndValue[1]);

                            else if(trim($productDataFieldAndValue[0])=="Płeć:")
                                $product["gender"]=trim($productDataFieldAndValue[1]);

                            else if(trim($productDataFieldAndValue[0])=="Opis|dodatkowy:")
                            {
                                $product["description"]=trim($productDataFieldAndValue[1]);
                            }
                        }                    
                    }
                }

                $productData = $xpath->query('//p[@class="product__data__price__regular"]');
                if ($productData->length > 0) {
                    $product["price"]=str_replace(" ","|",trim($productData->item(0)->nodeValue));
                }

                $productData = $xpath->query('//p[@class="product__data__price__list"]');
                if ($productData->length > 0) {
                    $product["original_price"]=str_replace(" ","|",trim($productData->item(0)->nodeValue));
                }

                $productData = $xpath->query('//h1[@class="product__header__name"]');
                if ($productData->length > 0) {
                    $product["name"]=str_replace(" ","|",trim($productData->item(0)->nodeValue));
                }

                $productData = $xpath->query('//img[@class="zoom_item js--gallery-thumbs-item"]');
                if ($productData->length > 0) {
                    $product["image_url"]=str_replace(" ","|",trim($productData->item(0)->getAttribute('src')));
                }
                $product["url"]=$productLink;

                $productDescriptionsArray=explode("~",$product["description"]);                    
                $productDescriptions='';
                foreach ($productDescriptionsArray as $description) {
                    $productDescriptions=$productDescriptions.$description.'<br />'; 
                }
                $xmlString =$xmlString.'<id>'.$product["id"].'</id>'.'<url>'.$product["url"].'</url>'.PHP_EOL.'<name>'.$product["name"].'</name>'.PHP_EOL.'<price>'.$product["price"].'</price>'.PHP_EOL.'<original_price>'.$product["original_price"].'</original_price>'.PHP_EOL.'<manufacturer>'.$product["manufacturer"].'</manufacturer>'.PHP_EOL.'<gender>'.$product["gender"].'</gender>'.PHP_EOL.'<description>'.$productDescriptions.'</description>'.PHP_EOL.'<image_url>'.$product["image_url"].'</image_url>'.PHP_EOL.'</item>';
                if($writeToDatabase)
                {
                    $query='INSERT INTO products (id, url, name, price, original_price, manufacturer, gender, description, image_url) VALUES ("'.$product["id"].'", "'.$product["url"].'", "'.$product["name"].'", "'.$product["price"].'", "'.$product["original_price"].'", "'.$product["manufacturer"].'", "'.$product["gender"].'", "'.$product["description"].'", "'.$product["image_url"].'")';
                    $database->query(strtr($query, 'ĘÓĄŚŁŻŹĆŃęóąśłżźćń', 'EOASLZZCNeoaslzzcn'));
                }           


            }
        }
            $xmlString =$xmlString.PHP_EOL.'</rss>';



            $xmlFile = fopen('product.xml', "w") ;        
            fwrite($xmlFile, str_replace("~","&#xD &#xA",str_replace("|"," ",$xmlString)));
            fclose($xmlFile);
            header('Location: index.php?action=productXml');
    }

    $content = getView('productForm', array('info' => $info)); 
?>