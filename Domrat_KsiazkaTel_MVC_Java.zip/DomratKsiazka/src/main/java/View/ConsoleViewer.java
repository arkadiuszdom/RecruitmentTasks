package View;

import java.util.List;

public class ConsoleViewer implements Viewer {

    public void view(String string) {
        System.out.println(string);        
    }

}
