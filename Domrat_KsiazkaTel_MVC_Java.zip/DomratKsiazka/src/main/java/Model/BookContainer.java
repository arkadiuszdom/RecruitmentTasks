package Model;

import java.util.ArrayList;
import java.util.List;

public class BookContainer implements Container<Person> {
    private List<Person>persons;
    
    public BookContainer() {
        this.persons=new ArrayList<Person>();
    }

    public List<Person> getSelectedByName(String surname)
    {
        List<Person> personsWithSurname=new ArrayList<Person>();
        for(int i=0; i<this.persons.size(); i++) {           
            if(this.persons.get(i).getSurname()==surname) {
                personsWithSurname.add(this.persons.get(i));
            }
        }
        return personsWithSurname;
    }
    
    public List<Person> getSelectedByNumberPrefix(String prefix)
    {
        List<Person> personsWithNumber=new ArrayList<Person>();
        for(int i=0; i<this.persons.size(); i++) {
            String curPrefix=this.persons.get(i).getNumber().substring(0,prefix.length());
            if(curPrefix.equals(prefix)) {
                personsWithNumber.add(this.persons.get(i));
            }
        }
        return personsWithNumber;
    }
    public List<Person> getAll() {
        List<Person> personsCopy = new ArrayList<Person>();
        for(int i=0; i<this.persons.size(); i++) {           
            personsCopy.add(this.persons.get(i));
        }
        return personsCopy;
    }

    public void Add(Person person) {
        this.persons.add(person);
        
    }
    
}
