<!DOCTYPE html>
<html>
<br>
<h2>Pobieranie pliku XML</h2> 
<br>
<strong><?=$info?></strong>
<a href="product.xml">POBIERZ</a>
<br>
<br>
<a href="index.php">Wróc</a>
</html>