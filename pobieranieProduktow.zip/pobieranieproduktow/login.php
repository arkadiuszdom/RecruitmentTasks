<?php    
    if(isset($_POST['username']) && isset($_POST['password'])){
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);
        if($username == '' || $password == '')
        {
            $info = 'Nie podano wymaganych danych';
        }
        else if($username != $_SESSION["username"] || $password != $_SESSION["password"])
        {
            $info = 'Podano niepoprawne dane';
        }
        else
        {
            $info="Zalogowano";
            header('Location: index.php?action=logged');
        }
    }
    
    $content = getView('login', array('info' => $info)); 



?>
