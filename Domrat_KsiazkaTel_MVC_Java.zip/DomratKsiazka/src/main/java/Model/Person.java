package Model;

public class Person {
    private String firstName;
    private String surname;
    private String number;
    
    public Person(String firstName, String surname, String number)
    {
        this.firstName=firstName;
        this.surname=surname; 
        this.number=number;
    }
    
    public String getFirstName()
    {
        return this.firstName;
    }
    public String getSurname()
    {
        return this.surname;
    }
    public String getNumber()
    {
        return this.number;
    }
    
    @Override
    public String toString()
    {
        return "Imie: "+this.firstName + " Nazwisko: " + this.surname+ " Numer: " + this.number;
    }
}
