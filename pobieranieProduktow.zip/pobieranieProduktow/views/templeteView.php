<!DOCTYPE html>
<html>
<h1 class="panel">Arkadiusz Domrat</h1>
<h1 class="panel">Pobieranie produktów</h1>
<title>Pobieranie produkt</title>	
<meta charset="utf-8">
<?=$content?>
</html>