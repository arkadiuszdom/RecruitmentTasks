package DomratKsiazka.DomratKsiazka;



import org.junit.Test;

import Controller.BookController;
import Model.BookContainer;
import View.ConsoleViewer;
import View.Viewer;


public class AppTest 
{
    @Test
    public void testApp() {
        
        BookContainer book=new BookContainer();
        Viewer console=new ConsoleViewer();
        BookController controller = new BookController(book, console);
        
        controller.readFrom("book.csv");
        
        controller.add("Jan", "Kowalski", "+241151252");
        controller.add("Bartosz", "Nowak", "+33151252");
        controller.add("Piotr", "Kowalski", "941151252");
        controller.add("Piotr", "Tryn", "+481151252");
        controller.add("Tomasz", "Kowalski", "+481151252");
        
        controller.writeTo("book.csv");
        
        System.out.println("Wszystkie kontakty:");
        controller.view(controller.getAll());
        
        System.out.println("\nWszystkie kontakty o nazwisku Kowalski:");
        controller.view(controller.getAllByName("Kowalski"));
        
        System.out.println("\nWszystkie kontakty o numerze zaczynającym się od +48:");
        controller.view(controller.getAllByNumber("+48"));
    }
}
