<!DOCTYPE html>
<html>
<br>
<h2>Logowanie</h2> 
<br>
<h3>Nazwa użytkownika: <?=$_SESSION["username"]?></h3> 
<h3>Hasło: <?=$_SESSION["password"]?></h3> 
<br>
<strong><?=$info?></strong>
<form method="POST">
	<label><input type="text" name="username" value="Nazwa_użytkownika"></label>
	<br>
	<br>
	<label><input type="password" name="password" value="Hasło"></label>
	<br>
	<br>
	<input type="submit" value="Zaloguj">
</form>
</html>