<!DOCTYPE html>
<html>
<br>
<h2>Wprowadzanie produktów</h2> 
<br>
<h3>Adresy URL produktów jeden pod drugim</h3>  
<br>
<strong><?=$info?></strong>
<form method="POST">
	<textarea name="productLinks" cols="100" rows="25"></textarea>
	<br>
	<input type="submit" value="Pobierz produkty">
</form>
</html>