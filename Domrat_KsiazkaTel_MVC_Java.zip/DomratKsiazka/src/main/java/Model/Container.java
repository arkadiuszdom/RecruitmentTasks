package Model;

import java.util.List;

public interface Container<T>
{
    public List<T> getAll();
    public void Add(T t);
    
}
