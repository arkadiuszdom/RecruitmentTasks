package Controller;

import java.util.List;


public interface Controller {
    public void readFrom(String path);
    public void writeTo(String path);
    public void view(List<String>strings);
    public List<String> getAll();
    
}
