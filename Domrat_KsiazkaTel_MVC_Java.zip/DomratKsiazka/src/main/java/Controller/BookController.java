package Controller;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import Model.BookContainer;
import Model.Person;
import View.Viewer;

public class BookController implements Controller{
    private BookContainer model;
    private Viewer view;
    
    public BookController(BookContainer model, Viewer view) {
        this.model=model;
        this.view=view;
    }
    public void view(List<String>strings)
    {
        for(int i=0; i<strings.size();i++) {
            this.view.view(strings.get(i).toString());
        }
        
    }
    public List<String> getAllSerialised() {
        List<String> strings = new ArrayList<String>();
        List<Person> items=this.model.getAll();
        for(int i=0; i<items.size();i++) {
            strings.add(items.get(i).getFirstName()+","+items.get(i).getSurname()+","+items.get(i).getNumber());
        }
        return strings;
             
     }
    public List<String> getAll() {
       List<String> strings = new ArrayList<String>();
       List<Person> items=this.model.getAll();
       for(int i=0; i<items.size();i++) {
           strings.add(items.get(i).toString());
       }
       return strings;
            
    }
    public List<String> getAllByName(String name) {
        List<String> strings = new ArrayList<String>();
        List<Person> items=this.model.getSelectedByName(name);
        for(int i=0; i<items.size();i++) {
            strings.add(items.get(i).toString());
        }
        return strings;
             
     }
    public List<String> getAllByNumber(String prefix) {
        List<String> strings = new ArrayList<String>();
        List<Person> items=this.model.getSelectedByNumberPrefix(prefix);
        for(int i=0; i<items.size();i++) {
            strings.add(items.get(i).toString());
        }
        return strings;
             
     }
     public void add(String firstName, String surname, String number) {
        model.Add(new Person(firstName, surname, number));
             
     }
    public void readFrom(String path) {
        File file = new File(path);
        List<String> readText = new ArrayList<String>();
        if (file.exists()) {
            try {
                readText = Files.readAllLines(file.toPath(), Charset.defaultCharset());
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            if (readText.isEmpty()) {
                return;
            }
        }
        for(int i=0; i<readText.size(); i++) {
            String[] res = readText.get(i).split(",");
            if(res.length==3)
            {
                this.add(res[0],res[1],res[2]);
            }
            
        }
        
    }
    public void writeTo(String path) {
        List<String>allStrings=this.getAllSerialised();
        String str="";
        for(int i=0; i<allStrings.size();i++) {
            str+=allStrings.get(i)+"\n";
        }
        byte[] strToBytes = str.getBytes();
        Path path1 = Paths.get(path);
        try {
            Files.write(path1, strToBytes);       
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
