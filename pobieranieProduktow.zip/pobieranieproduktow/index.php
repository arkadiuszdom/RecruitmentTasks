
<?php
    session_start();

    /*$database = mysqli_connect('localhost', 'root', '' );
    $query='CREATE DATABASE pobieranieProduktow';
    $database->query($query);
    $database = mysqli_connect('localhost', 'root', '', 'pobieranieProduktow');
    $query='CREATE TABLE products (product_id int AUTO_INCREMENT, id varchar(20), url varchar(100), name varchar(40), price varchar(10), original_price varchar(10), manufacturer varchar(40), gender varchar(10), description varchar(5000), image_url varchar(100), PRIMARY KEY (product_id) ); ';
    $database->query($query);*/
    $_SESSION["username"] = "user";
    $_SESSION["password"] = "123";

    error_reporting(E_ALL & ~E_NOTICE);//$_GET['action'] moze nie istniec
    include 'outputBuffer.php';
    switch ($_GET['action']) 
    {
        case 'logged':
            include 'productForm.php';
            break;
        case 'productXml':
            include 'productXml.php';
            break;
        default:
            include 'login.php';
            break;
        
    }
    $template = getView('templete', array('content' => $content));

    echo $template; 
?>