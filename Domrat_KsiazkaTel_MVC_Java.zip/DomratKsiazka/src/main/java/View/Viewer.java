package View;


public interface Viewer {
    public void view(String string);
    
}
