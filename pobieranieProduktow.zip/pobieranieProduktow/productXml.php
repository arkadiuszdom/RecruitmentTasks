<?php
    $content = getView('productXml', array('info' => $info)); 
    session_destroy();
?>	